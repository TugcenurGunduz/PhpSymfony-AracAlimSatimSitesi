<?php
    /**
     * Your Twitter App Info
     */
    
    // Consumer Key
    define('CONSUMER_KEY', '75yoCDzPyBCcIlMxL7VZpJkRc');
    define('CONSUMER_SECRET', 'B9AG8CCkbDroDul9a5myzS8UGniao4cw2lGwqXSQPUkGPPE2Bj');

    // User Access Token
    define('ACCESS_TOKEN', '3110208648-fkEAaPcHerhBz2QpBF0F51UpnQLqlo0BGx6C20j');
    define('ACCESS_SECRET', 'V2HEqaROWMpGrfemhT2Ol2hpqtQPYqmFAp4UXaz83Ra0V');
	
	// Cache Settings
	define('CACHE_ENABLED', false);
	define('CACHE_LIFETIME', 3600); // in seconds
	define('HASH_SALT', md5(dirname(__FILE__)));
	
